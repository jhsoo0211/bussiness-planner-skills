# bizplan GPT/Codex 플러그인 v0.4.0

0.3.1의 15개 사업계획서 스킬과 사례·평가·시각화 자료를 GPT/Codex 플러그인 규격으로 이전한 로컬 마켓플레이스 묶음입니다.

- 플러그인: `plugins/bizplan`
- 마켓플레이스 설정: `.agents/plugins/marketplace.json`
- 자체 점검: `python3 plugins/bizplan/scripts/self_check.py --smoke-charts`
- 상세 품질 평가: `QUALITY_REPORT.md`

압축을 푼 폴더를 로컬 마켓플레이스로 추가한 뒤 `bizplan`을 설치합니다. 설치 후 자연어로 요청하거나 `$bizplan`을 선택할 수 있습니다.
