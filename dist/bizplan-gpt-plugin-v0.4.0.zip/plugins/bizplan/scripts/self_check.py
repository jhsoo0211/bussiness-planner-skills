#!/usr/bin/env python3
"""bizplan 플러그인의 구조·라우팅·차트 회귀 검사를 한 번에 실행한다."""

from __future__ import annotations

import argparse
import importlib.util
import json
import re
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
EXPECTED_SKILLS = {
    "bizplan",
    "bizplan-analyze",
    "bizplan-export",
    "bizplan-growth",
    "bizplan-item",
    "bizplan-pitch",
    "bizplan-problem",
    "bizplan-quick",
    "bizplan-research",
    "bizplan-review",
    "bizplan-slides",
    "bizplan-solution",
    "bizplan-summary",
    "bizplan-team",
    "bizplan-visual",
}


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def check_json() -> None:
    for path in [
        ROOT / ".codex-plugin" / "plugin.json",
        ROOT / "evals" / "trigger-evals.json",
        ROOT / "evals" / "workflow-evals.json",
    ]:
        json.loads(path.read_text(encoding="utf-8"))


def check_skills() -> None:
    skill_dirs = {p.parent.name: p.parent for p in (ROOT / "skills").glob("*/SKILL.md")}
    require(set(skill_dirs) == EXPECTED_SKILLS, "스킬 15종의 이름 또는 수가 기준과 다릅니다.")

    for name, folder in sorted(skill_dirs.items()):
        skill_text = (folder / "SKILL.md").read_text(encoding="utf-8")
        match = re.match(r"^---\n(.*?)\n---\n", skill_text, flags=re.DOTALL)
        require(match is not None, f"{name}: YAML 프런트매터가 없습니다.")
        require(re.search(rf"^name:\s*{re.escape(name)}\s*$", match.group(1), flags=re.MULTILINE) is not None,
                f"{name}: 프런트매터 이름이 폴더와 다릅니다.")

        agent_path = folder / "agents" / "openai.yaml"
        agent_text = agent_path.read_text(encoding="utf-8")
        require(f'${name}' in agent_text, f"{name}: 기본 프롬프트에 ${name}이 없습니다.")


def check_platform_migration() -> None:
    forbidden = re.compile(r"Claude|Anthropic|Opus|Sonnet|Haiku|Fable|\.claude", re.IGNORECASE)
    for path in ROOT.rglob("*"):
        if path.resolve() == Path(__file__).resolve():
            continue
        if path.is_file() and path.suffix.lower() in {".md", ".json", ".yaml", ".py"}:
            match = forbidden.search(path.read_text(encoding="utf-8"))
            if match is not None:
                raise AssertionError(f"Claude 전용 표현이 남았습니다: {path} ({match.group(0)})")

    font_dir = ROOT / "skills" / "bizplan-visual" / "assets" / "fonts"
    require((font_dir / "NanumGothic-Regular.ttf").is_file(), "번들 한글 폰트가 없습니다.")
    require((font_dir / "OFL-NanumGothic.txt").is_file(), "폰트 라이선스가 없습니다.")


def smoke_charts() -> None:
    chart_path = ROOT / "skills" / "bizplan-visual" / "scripts" / "chart_templates.py"
    spec = importlib.util.spec_from_file_location("bizplan_chart_templates", chart_path)
    require(spec is not None and spec.loader is not None, "차트 모듈을 불러올 수 없습니다.")
    charts = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(charts)
    require(charts.setup_korean_font() is not None, "번들 한글 폰트를 등록하지 못했습니다.")

    with tempfile.TemporaryDirectory(prefix="bizplan-charts-") as tmp:
        out = Path(tmp)
        outputs = [
            charts.bar_compare(["자사", "경쟁 A"], [90, 60], "비교", "점수", out / "bar.png"),
            charts.growth_line([2024, 2025, 2026], [100, 130, 170], "성장", "억 원", out / "growth.png"),
            charts.tam_sam_som(1000, 300, 30, out=out / "tam.png"),
            charts.positioning_map({"자사": (8, 8), "경쟁 A": (4, 5)}, "편의성", "정확성", out / "position.png", ours="자사"),
            charts.gantt([("개발", 1, 2), ("검증", 3, 1)], out / "gantt.png"),
        ]
        require(all(Path(path).is_file() and Path(path).stat().st_size > 0 for path in outputs),
                "차트 5종 중 생성에 실패한 파일이 있습니다.")

        try:
            charts.tam_sam_som(100, 200, 10, out=out / "invalid.png")
        except ValueError:
            pass
        else:
            raise AssertionError("잘못된 TAM/SAM/SOM 입력이 차단되지 않았습니다.")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--smoke-charts", action="store_true", help="한글 폰트와 차트 5종까지 생성 검사")
    args = parser.parse_args()

    check_json()
    check_skills()
    check_platform_migration()
    if args.smoke_charts:
        smoke_charts()
    print(f"PASS: bizplan v0.4.0 — {len(EXPECTED_SKILLS)} skills" +
          (", chart smoke 5/5" if args.smoke_charts else ""))


if __name__ == "__main__":
    main()
