# GPT 시각자료 프롬프트 라이브러리

## 기본 원칙

정확한 숫자·축·긴 한글 문장·복잡한 화살표는 이미지 생성 모델에 맡기지 않는다. 배경·제품·사용 장면·시각적 은유를 생성한 뒤, 정확한 라벨과 수치는 PPT·SVG·차트로 올린다.

프롬프트는 사용자의 요구를 보존하면서 다음 구조로 정리한다.

```text
Use case: <productivity-visual | infographic-diagram | product-mockup | photorealistic-natural>
Asset type: <사업계획서 A4 도식 | 16:9 발표 슬라이드 | 제품 사용 장면>
Primary message: <이 이미지가 증명해야 할 한 문장>
Audience: Korean government-program evaluators and startup judges
Scene/backdrop: <환경>
Subject: <핵심 주체>
Composition: <좌우/상하/순환/중앙 허브, 시선 흐름, 여백>
Style: <flat vector | editorial photo | clean 3D product render>
Color palette: <기본색 1개 + 강조색 1개 + 흰 배경>
Text strategy: no embedded text; reserve clean label areas
Must keep: <필수 요소>
Avoid: distorted Korean text, random logos, watermark, dollar signs, American corporate clip art, handshakes, cartoon mascots, decorative clutter
```

## 1. 문제 → 솔루션 전환 도식

```text
Use case: infographic-diagram
Asset type: A4 Korean government business plan visual
Primary message: "분산된 고객 문제를 하나의 통합 솔루션이 해결한다"
Audience: Korean public startup-program evaluators
Composition: a clear left-to-right transformation. On the left, three visually distinct pain-point scenes arranged vertically; in the center, one restrained transition arrow zone; on the right, one unified product or service outcome. Reserve three clean label boxes on the left and three on the right, but render no text inside them.
Style: premium flat vector infographic, restrained Korean public-sector business tone, white background, navy as the primary color and teal as the accent
Must keep: exactly three pain points and exactly three corresponding solution outcomes, aligned one-to-one
Avoid: embedded text, random icons, decorative gradients, comic style, handshakes, dollar signs, logos, watermark
```

생성 후 PPT에서 `문제 1↔기능 1`, `문제 2↔기능 2`, `문제 3↔기능 3` 라벨과 근거 수치를 올린다.

## 2. 서비스 사용 시나리오

```text
Use case: productivity-visual
Asset type: 16:9 pitch-deck scenario illustration
Primary message: "사용자가 서비스를 처음 인지하고 핵심 가치를 얻는 과정"
Composition: four sequential scenes flowing from left to right with consistent characters and product appearance. Leave a clean title band at the top and a caption zone under each scene. No text in the image.
Style: clean editorial illustration with realistic proportions, modern Korean urban context, calm professional tone, white and light-gray background, one blue accent color
Must keep: the same user and the same product in all four scenes; clear progression; generous negative space
Avoid: distorted hands, changing device design, speech bubbles, embedded labels, cartoon mascot, stock-photo handshake, watermark
```

## 3. 제품 콘셉트·사용 장면

```text
Use case: product-mockup
Asset type: business-plan product concept image
Primary message: "이 제품이 실제 사용 환경에서 자연스럽게 작동한다"
Scene/backdrop: <실제 사용 장소>
Subject: <제품> being used by <1차 타깃 고객>
Composition: three-quarter product view, user interaction clearly visible, product remains the visual focus, right-side negative space for a Korean headline
Style: realistic product visualization, credible materials, soft natural lighting, restrained commercial photography
Must keep: <크기·구성·핵심 부품·색상>
Avoid: impossible mechanics, extra buttons, random logos, embedded text, medical claims not provided by the user, watermark
```

## 4. 비즈니스 모델 순환 구조

정확한 화살표와 라벨이 필요하므로 PPT 도형을 기본으로 한다. 이미지 생성은 배경 개념 요소가 필요할 때만 사용한다.

```text
Use case: infographic-diagram
Asset type: background visual for a 16:9 business-model slide
Primary message: "고객·파트너·플랫폼 사이의 가치 흐름"
Composition: three clean visual zones positioned at left, center, and right around an empty circular flow area. Reserve ample blank space for editable arrows and Korean labels to be added later in PowerPoint. No text, no arrows, no currency symbols.
Style: minimal premium vector, white background, navy and emerald accent, subtle depth only
Must keep: three distinct stakeholder zones and a clear central service hub
Avoid: embedded labels, arrows, money icons, handshake clichés, busy gradients, watermark
```

## 5. 고객 여정 Before / After

```text
Use case: infographic-diagram
Asset type: split-screen business-plan illustration
Primary message: "도입 전의 반복 문제와 도입 후의 개선된 경험"
Composition: balanced split screen. Left side shows the current painful workflow with three subtle friction cues; right side shows the improved workflow with the same person, environment, and task. Reserve a clean top headline area and bottom metric boxes. No text.
Style: restrained editorial vector illustration, consistent character identity, Korean workplace or home context, gray left side and blue-green right side
Must keep: same user, same task, comparable scene geometry
Avoid: exaggerated sadness or celebration, text, logos, magical effects, watermark
```

## 6. 기술·서비스 구조도

정확한 구조도는 SVG·PPT 도형으로 만든다. 다음 사양으로 먼저 와이어프레임을 구성한다.

```text
Top row: user channels
Middle row: core service modules
Bottom row: data, AI, external APIs, security
Flow: top-to-bottom request flow and bottom-to-top feedback flow
Each node: 2–4 Korean words
Each arrow: one direction and one verb
Evidence badges: only where a prototype, API, dataset, or test result exists
```

필요하면 이미지 생성으로 배경 아이콘 세트만 만들고, 노드·화살표·텍스트는 편집 가능한 도형으로 제작한다.

## 7. 프롬프트와 결과 검수

1. 프롬프트에 없는 브랜드·기능·성과가 추가되지 않았는가.
2. 제품 외형과 사용자 정체성이 장면마다 유지되는가.
3. 한글·숫자·로고가 정확한가. 틀리면 라벨 없는 버전으로 재생성한다.
4. A4 또는 16:9에서 제목과 본문을 올릴 여백이 있는가.
5. 이미지가 장식이 아니라 문서의 주장과 연결되는가.
6. AI 생성 콘셉트 이미지임을 증빙 사진처럼 오해하게 배치하지 않았는가.
