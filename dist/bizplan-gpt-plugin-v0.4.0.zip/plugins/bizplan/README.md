# bizplan — GPT/Codex 사업계획서 플러그인

공고문·평가표·제출 양식과 팀 자료를 분석해 한국어 사업계획서, 검토 보고서, 발표 대본, PPTX, PDF, 차트와 도식을 만드는 PSST 기반 플러그인입니다.

## 핵심 기능

- 상황에 맞게 자동으로 작업 모드를 선택하고, 정말 필요한 경우에만 GPT 네이티브 선택 버튼 사용
- 한 번에 최대 3개 질문, 정보가 부족하면 기획 요약 초안 우선
- 공고문·평가표·제출 양식의 목차와 분량을 기본 템플릿보다 우선
- 팀 연혁·시제품·실측·MOU·LOI·매출 등 실제 자료를 본문 근거로 반영
- 공식 평가표 또는 명시한 가정 루브릭으로 재현 가능한 검토
- DOCX·PPTX·PDF 실제 제작과 페이지·슬라이드 렌더링 검수
- 코드 기반 정확 차트, 편집 가능한 도식, GPT 이미지 생성을 조합한 시각자료 제작
- OFL 라이선스 NanumGothic을 번들해 한글 차트 깨짐 방지

## 스킬

`bizplan` 라우터와 `bizplan-quick`, `bizplan-item`, `bizplan-problem`, `bizplan-research`, `bizplan-solution`, `bizplan-growth`, `bizplan-team`, `bizplan-summary`, `bizplan-visual`, `bizplan-review`, `bizplan-pitch`, `bizplan-slides`, `bizplan-export`, `bizplan-analyze`를 포함합니다.

## 사용 예시

- “첨부한 공고문과 평가표를 분석해서 사업계획서 작성을 시작해줘.”
- “이 초안을 공식 배점표에 맞춰 채점하고 수정안을 만들어줘.”
- “사업계획서를 바탕으로 7분 발표용 PPTX와 예상 Q&A를 만들어줘.”
- “문제-솔루션 도식과 제품 사용 장면을 GPT 이미지 생성으로 직접 만들어 PPT에 넣어줘.”

## 로컬 테스트

이 배포 묶음의 `.agents/plugins/marketplace.json`을 포함한 루트 디렉터리를 로컬 마켓플레이스로 추가한 뒤, ChatGPT Work/Codex의 Plugins 화면에서 `bizplan`을 설치합니다. 설치 후 새 대화에서 `$bizplan`을 직접 선택하거나 자연어로 요청할 수 있습니다.

## 중요 원칙

- 최신 공고·법규·시장 정보는 공식 출처로 확인합니다.
- 확인되지 않은 수치와 합격 가능성을 사실처럼 단정하지 않습니다.
- AI 생성 콘셉트 이미지를 시제품·실적 증빙처럼 표시하지 않습니다.
- 정확한 수치·축·한글 라벨은 이미지 생성 모델보다 차트·PPT 도형을 우선합니다.
